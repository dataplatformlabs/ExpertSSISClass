select * from [dbo].[Customers] --Type 0: CustomerFirstName, CustomerLastName Type 1: Address, City, State, Zip, Country, Type 2: PhoneNumber, FaxNumber, Email
SELECT * FROM [dbo].[Employee] --Type 0: FirstName Type 1: LastName Type 2: PhoneNumber, FaxNumber, Email
SELECT * FROM  [dbo].[Product]
SELECT * FROM  [dbo].Supplier
SELECT * FROM  [dbo].[Orders]

--1st Dimension Customer
-----------------------------
--Customers:- SCD Example Start
exec WorkDB.[dbo].[resetFameSell]
--Type 0: CustomerFirstName, CustomerLastName Type 1: Address, City, State, Zip, Country, Type 2: PhoneNumber, FaxNumber, Email
select * from [dbo].[Customers] 
go
--SCD Type 0
update [dbo].[Customers]
set CustomerFirstName = 'Debra'
where CustomerID = 1
go
--SCD Type 1
update [dbo].[Customers]
set Address = '100 East Cowley Street'
where CustomerID = 2
go
--SCD Type 2
update [dbo].[Customers]
set Email = 'daniel@gmail.com',
ValidFrom = getdate()
where CustomerID = 5
go
--Insert a new record
insert into  [dbo].[Customers] 
SELECT 15000, 'Data' ,'PlatFormLabs', [PhoneNumber], [FaxNumber], [Email], [Address], [City], [State], [Zip], [Country],getdate(), [ValidTo]
 FROM [dbo].[Customers] where CustomerID =4
go
--Customers:- SCD Example End
--------------------------------------------
--Type 0: CustomerFirstName, CustomerLastName Type 1: Address, City, State, Zip, Country, Type 2: PhoneNumber, FaxNumber, Email
select * from [dbo].[Customers] 
exec WorkDB.[dbo].[ResetFameSell]
go
--Customers:- Microsoft Solution Example Start
--SCD Type 2
update [dbo].[Customers]
set PhoneNumber = '1112223333',
ValidFrom = getdate()
where CustomerID = 2
go
--SCD Type 2
update [dbo].[Customers]
set Email = 'daniel@gmail.com',
ValidFrom = getdate()
where CustomerID = 5
go
--Insert a new record
insert into  [dbo].[Customers] 
SELECT 15000, 'Data' ,'PlatFormLabs', [PhoneNumber], [FaxNumber], [Email], [Address], [City], [State], [Zip], [Country],getdate(), [ValidTo]
 FROM [dbo].[Customers] where CustomerID =4
go
--Customers:- Microsoft Solution Example End
-----------------------------
--Customers: Lookup Example Start
--Type 0: CustomerFirstName, CustomerLastName Type 1: Address, City, State, Zip, Country, Type 2: PhoneNumber, FaxNumber, Email
select * from [dbo].[Customers] 
exec WorkDB.[dbo].[resetFameSell]
go
--SCD Type 0
update [dbo].[Customers]
set CustomerFirstName = 'Debra'
where CustomerID = 1
go
--SCD Type 1
update [dbo].[Customers]
set Address = '100 East Cowley Street'
where CustomerID = 2
go
--SCD Type 2
--Update Customer PhoneNumber
update [dbo].[Customers]
set PhoneNumber = '1112223333'
where CustomerID = 3
go
--Insert a new Customer
insert into  [dbo].[Customers] 
SELECT 15000, 'Data' ,'PlatFormLabs', [PhoneNumber], [FaxNumber], [Email], [Address], [City], [State], [Zip], [Country],getdate(), [ValidTo]
 FROM [dbo].[Customers] where CustomerID =4
go
--Customers: Lookup Example End
-----------------------------
--Customers: Hash Example Start
exec WorkDB.[dbo].[resetFameSell]
--Type 0: CustomerFirstName, CustomerLastName Type 1: Address, City, State, Zip, Country, Type 2: PhoneNumber, FaxNumber, Email
select * from [dbo].[Customers] 
go
--SCD Type 0
update [dbo].[Customers]
set CustomerFirstName = 'Debra'
where CustomerID = 1
go
--SCD Type 1
update [dbo].[Customers]
set Address = '100 East Cowley Street'
where CustomerID = 2
go
--SCD Type 2
update [dbo].[Customers]
set FaxNumber = '111-2223333'
where CustomerID = 5
go
--Insert a new Customer
insert into  [dbo].[Customers] 
SELECT 15000, 'Data' ,'PlatFormLabs', [PhoneNumber], [FaxNumber], [Email], [Address], [City], [State], [Zip], [Country],getdate(), [ValidTo]
 FROM [dbo].[Customers] where CustomerID =4
go
--Customers: Hash Example End
--------------------------------------------------
--2nd Dimension Employee
SELECT * FROM [dbo].[Employee] 
--Type 0: FirstName Type 1: LastName Type 2: PhoneNumber, FaxNumber, Email

exec WorkDB.[dbo].[ResetFameSell]
go
--Employee: Microsoft Solution Example Start
--SCD Type 2
update [dbo].Employee
set Email = 'Nicole@gmail.com',
ValidFrom = getdate()
where EmployeeID = 1
go
--SCD Type 2
update [dbo].Employee
set PhoneNumber = '1112223333',
ValidFrom = getdate()
where EmployeeID = 2
go
--Insert a new Employee
insert into  [dbo].Employee 
SELECT 200 AS EmployeeID, [FirstName], [LastName], [IsPermittedToLogon], [LogonName], [IsSalesperson], [PhoneNumber], [FaxNumber], [Email], GETDATE(),
[ValidTo] FROM [dbo].Employee where EmployeeID =4
go
--Employee: Microsoft Solution Example End
---------------------------------------------
--Employee: SCD Example Start
exec WorkDB.[dbo].[resetFameSell]
go
SELECT * FROM [dbo].[Employee] 
--Type 0: FirstName Type 1: LastName Type 2: PhoneNumber, FaxNumber, Email

--SCD Type 0
update [dbo].Employee
set FirstName = 'Debra'
where EmployeeID = 1
go
--SCD Type 1
update [dbo].Employee
set LastName = 'Ryan'
where EmployeeID = 2
go
--SCD Type 2
update [dbo].Employee
set Email = 'Pablo@gmail.com',
ValidFrom = getdate()
where EmployeeID = 3
go
--Insert a new Employee
insert into  [dbo].Employee 
SELECT 200 AS EmployeeID, [FirstName], [LastName], [IsPermittedToLogon], [LogonName], [IsSalesperson], [PhoneNumber], [FaxNumber], [Email], GETDATE(),
[ValidTo] FROM [dbo].Employee where EmployeeID =4
--Employee: SCD Example End
--------------------------------------------
--Employee: Lookup Example Start
exec WorkDB.[dbo].[resetFameSell]
go
SELECT * FROM [dbo].[Employee] 
--Type 0: FirstName Type 1: LastName Type 2: PhoneNumber, FaxNumber, Email

--SCD Type 0
update [dbo].Employee
set FirstName = 'Debra'
where EmployeeID = 1
go
--SCD Type 1
update [dbo].Employee
set LastName = 'Ryan'
where EmployeeID = 2
go
--SCD Type 2
update [dbo].Employee
set Email = 'Pablo@gmail.com',
ValidFrom = getdate()
where EmployeeID = 3
go
--Insert a new Employee
insert into  [dbo].Employee 
SELECT 200 AS EmployeeID, [FirstName], [LastName], [IsPermittedToLogon], [LogonName], [IsSalesperson], [PhoneNumber], [FaxNumber], [Email], GETDATE(),
[ValidTo] FROM [dbo].Employee where EmployeeID =4
--Employee: Lookup Example End
-------------------------------------------------
--Employee: Hash Example Start
exec WorkDB.[dbo].[resetFameSell]
go
SELECT * FROM [dbo].[Employee] 
--Type 0: FirstName Type 1: LastName Type 2: PhoneNumber, FaxNumber, Email

--SCD Type 0
update [dbo].Employee
set FirstName = 'Debra'
where EmployeeID = 1
go
--SCD Type 1
update [dbo].Employee
set LastName = 'Ryan'
where EmployeeID = 2
go
--SCD Type 2
update [dbo].Employee
set Email = 'Pablo@gmail.com',
ValidFrom = getdate()
where EmployeeID = 3
go
--Insert a new Employee
insert into  [dbo].Employee 
SELECT 200 AS EmployeeID, [FirstName], [LastName], [IsPermittedToLogon], [LogonName], [IsSalesperson], [PhoneNumber], [FaxNumber], [Email], GETDATE(),
[ValidTo] FROM [dbo].Employee where EmployeeID =4
--Employee: Hash Example End
-----------------------------------------------------
--Product\Supplier: Microsoft Solution Example Start

--3rd Dimension Product
SELECT * FROM [dbo].Product a inner join Supplier b on a.supplierid = b.supplierid
--Type 0: Barcode Type 1: ProductName, Color, Brand, Size Type 2: TaxRate, UnitPrice
SELECT * FROM [dbo].Supplier 
--Type 0: Type 1: SupplierName Type 2: PhoneNumber, Email

exec WorkDB.[dbo].[ResetFameSell]
go
--SCD Type 2
update [dbo].Product
set UnitPrice = 100,
ValidFrom = getdate()
where ProductID = 1
go
--SCD Type 2
update a
set a.PhoneNumber = '1112223333',
a.ValidFrom = getdate()
from [dbo].Supplier a 
where a.SupplierId = 2
go
select count(*) from [dbo].Product where SupplierId = 2
--53

--Insert a new Product
insert into  [dbo].Product 
SELECT 2000 as ProductID, [ProductName], [Color], [Brand], [Size], [Barcode], [TaxRate], [UnitPrice], [SupplierId], GETDATE(), [ValidTo] 
FROM [dbo].Product where ProductID =4
--Product\Supplier: Microsoft Solution Example End
-----------------------------------------------------  
--Product\Supplier: SCD Example Start

exec WorkDB.[dbo].[ResetFameSell]
go
SELECT * FROM [dbo].Product a inner join Supplier b on a.supplierid = b.supplierid
--Type 0: Barcode Type 1: ProductName, Color, Brand, Size Type 2: TaxRate, UnitPrice
SELECT * FROM [dbo].Supplier 
--Type 0: Type 1: SupplierName Type 2: PhoneNumber, Email

--SCD Type 0
update [dbo].Product
set Barcode = 'xyz'
where ProductID = 1
go
--SCD Type 1
update [dbo].Product
set Color = 'Red'
where ProductID = 2
go
--SCD Type 2
update [dbo].Product
set UnitPrice = 100
where ProductID = 3
go
--Insert a new Employee
insert into  [dbo].Employee 
SELECT 200 AS EmployeeID, [FirstName], [LastName], [IsPermittedToLogon], [LogonName], [IsSalesperson], [PhoneNumber], [FaxNumber], [Email], GETDATE(),
[ValidTo] FROM [dbo].Employee where EmployeeID =4
go
--Product\Supplier: SCD Example End
----------------------------------------------------------
--Product\Supplier: Lookup Example Start

exec WorkDB.[dbo].[ResetFameSell]
go
SELECT * FROM [dbo].Product a inner join Supplier b on a.supplierid = b.supplierid
--Type 0: Barcode Type 1: ProductName, Color, Brand, Size Type 2: TaxRate, UnitPrice
SELECT * FROM [dbo].Supplier 
--Type 0: Type 1: SupplierName Type 2: PhoneNumber, Email

--SCD Type 0
update [dbo].Product
set Barcode = 'xyz'
where ProductID = 1
go
--SCD Type 1
update [dbo].Product
set Color = 'Red'
where ProductID = 2
go
--SCD Type 2
update [dbo].Product
set UnitPrice = 100
where ProductID = 3
go
--Insert a new Employee
insert into  [dbo].Employee 
SELECT 200 AS EmployeeID, [FirstName], [LastName], [IsPermittedToLogon], [LogonName], [IsSalesperson], [PhoneNumber], [FaxNumber], [Email], GETDATE(),
[ValidTo] FROM [dbo].Employee where EmployeeID =4
go
--Product\Supplier: Lookup Example End
--------------------------------------------------------------
--Product\Supplier: Hash Example Start

exec WorkDB.[dbo].[ResetFameSell]
go
SELECT * FROM [dbo].Product a inner join Supplier b on a.supplierid = b.supplierid
--Type 0: Barcode Type 1: ProductName, Color, Brand, Size Type 2: TaxRate, UnitPrice
SELECT * FROM [dbo].Supplier 
--Type 0: Type 1: SupplierName Type 2: PhoneNumber, Email

--SCD Type 0
update [dbo].Product
set Barcode = 'xyz'
where ProductID = 1
go
--SCD Type 1
update [dbo].Product
set Color = 'Red'
where ProductID = 2
go
--SCD Type 2
update [dbo].Product
set UnitPrice = 100
where ProductID = 3
go
--Insert a new Employee
insert into  [dbo].Employee 
SELECT 200 AS EmployeeID, [FirstName], [LastName], [IsPermittedToLogon], [LogonName], [IsSalesperson], [PhoneNumber], [FaxNumber], [Email], GETDATE(),
[ValidTo] FROM [dbo].Employee where EmployeeID =4
go
--Product\Supplier: Hash Example End
-----------------------------------------------------------------
--Load Fact table: Orders Example Start

exec WorkDB.[dbo].[ResetFameSell]
go
SELECT * FROM Orders

--Add a new Order
insert into  [dbo].Orders ([OrderID]
           ,[ProductID]
           ,[SupplierId]
           ,[CustomerID]
           ,[Quantity]
           ,[UnitPrice]
           ,[TaxRate]
           ,[LastEditedBy]
           ,[LastEditedWhen]
           ,[LastEditedDate])
SELECT       20001 as [OrderID]
			,[ProductID]
           ,[SupplierId]
           ,[CustomerID]
           ,[Quantity]+30
           ,[UnitPrice]
           ,[TaxRate]
           ,[LastEditedBy]
           ,getdate()
           ,getdate() from Orders where OrderID =1
go
--Load Fact table: Orders Example End