select * from [Dimension].[Customer]
select * from [Integration].[Customer_Staging]
select * from Stg_Customer
select * from [Dimension].[Employee]
select * from [Integration].[Employee_Staging]
select * from Stg_Employee
select * from [Dimension].[Product]
select * from [Integration].[Product_Staging]
select * from Stg_Product
select * from [Dimension].[Date]
select * from Fact.Orders
select * from [Integration].[Lineage] order by [Lineage Key] desc
select * from [Integration].[ETL Cutoff] WHERE [TABLE NAME] = 'Customer'
select * from [Integration].[ETL Cutoff] WHERE [TABLE NAME] = 'Employee'
select * from [Integration].[ETL Cutoff] WHERE [TABLE NAME] = 'Product'
select * from [Integration].[ETL Cutoff] WHERE [TABLE NAME] = 'Orders'
select * from tbl_logs

insert into tbl_logs
select 'Lookup package','Package Started','',0,0,getdate()

/*
truncate table [Dimension].[Customer]
truncate table [Integration].[Customer_Staging]
truncate table Stg_Customer
go
truncate table [Dimension].[Employee]
truncate table [Integration].[Employee_Staging]
truncate table Stg_Employee
go
truncate table [Dimension].[Product]
truncate table [Integration].[Product_Staging]
truncate table Stg_Product
go
truncate table [Dimension].[Date]
truncate table Fact.Orders
go
exec [dbo].[proc_Populate_Date_Dimension]
*/
UPDATE [Integration].[ETL Cutoff]
SET [Cutoff Time] = '2000-01-01 00:00:00.0000000' where [Table Name] = 'Customer'
UPDATE [Integration].[ETL Cutoff]
SET [Cutoff Time] = '2000-01-01 00:00:00.0000000' where [Table Name] = 'Employee'
UPDATE [Integration].[ETL Cutoff]
SET [Cutoff Time] = '2000-01-01 00:00:00.0000000' where [Table Name] = 'Product'
UPDATE [Integration].[ETL Cutoff]
SET [Cutoff Time] = '2000-01-01 00:00:00.0000000' where [Table Name] = 'Orders'

--Customer
select * from FameSell..Customers where CustomerID=1
select * from [Dimension].[Customer] where CustomerID=1 ORDER BY CustomerSK
select * from FameSell..Customers where CustomerID=2
select * from [Dimension].[Customer] where CustomerID=2 ORDER BY CustomerSK
select * from FameSell..Customers where CustomerID =3
select * from [Dimension].[Customer] where CustomerID =3 ORDER BY CustomerSK
select * from FameSell..Customers where CustomerID =5 
select * from [Dimension].[Customer] where CustomerID =5 ORDER BY CustomerSK
select * from FameSell..Customers where CustomerID =15000
select * from [Dimension].[Customer] where CustomerID =15000 ORDER BY CustomerSK

--Employee
select * from FameSell..Employee where EmployeeID=1
select * from [Dimension].Employee where EmployeeID=1 ORDER BY EmployeeSK
select * from FameSell..Employee where EmployeeID=2
select * from [Dimension].Employee where EmployeeID=2 ORDER BY EmployeeSK
select * from FameSell..Employee where EmployeeID=3
select * from [Dimension].Employee where EmployeeID=3 ORDER BY EmployeeSK
select * from FameSell..Employee where EmployeeID=200
select * from [Dimension].Employee where EmployeeID=200 ORDER BY EmployeeSK

--Product
select * from FameSell..Product a inner join FameSell..Supplier b on a.SupplierId = b.SupplierId  where a.ProductID=1
select * from [Dimension].Product where ProductID=1 ORDER BY ProductSK
select * from FameSell..Product a inner join FameSell..Supplier b on a.SupplierId = b.SupplierId  where a.ProductID=2
select * from [Dimension].Product where ProductID=2 ORDER BY ProductSK
select * from FameSell..Product a inner join FameSell..Supplier b on a.SupplierId = b.SupplierId  where a.ProductID=3
select * from [Dimension].Product where ProductID=3 ORDER BY ProductSK
select * from FameSell..Product a inner join FameSell..Supplier b on a.SupplierId = b.SupplierId  where a.ProductID=200
select * from [Dimension].Product where ProductID=200 ORDER BY ProductSK

--Fact.Orders
select * from Fact.Orders--19,804
select * from FameSell..Orders where OrderID=20001
select * from Fact.Orders where OrderID=20001
