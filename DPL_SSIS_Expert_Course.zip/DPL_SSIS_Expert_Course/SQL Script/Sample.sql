create table test(Id int identity, FirstName varchar(100), LastName varchar(100), PhoneNumber varchar(10))
create table test2(Id int, FirstName varchar(100), LastName varchar(100), PhoneNumber varchar(10))
go
select * from test
select * from test2

insert into test
select 'Mohan50', '"Kumar|', NULL
union
select '#$%^Maahi', '&^%$#$%Singh', 'asdadkhlsd'
go

SELECT dbo.udfGetCharacters(ISNULL(FirstName,''),'A-Z ') as FirstName, dbo.udfGetCharacters(ISNULL(LastName,''),'A-Z ') as LastName, 
dbo.udfGetCharacters(ISNULL(PhoneNumber,''),'0-9 ') as PhoneNumber from test