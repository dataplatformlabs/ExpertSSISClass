select * from testdata


create table tbl_logs(Id int identity, Step_Name varchar(100), FlatFileName varchar(200), RecordsInserted int, Dated datetime)
create table tbl_errors(Id int identity, PackageName varchar(100), TaskName varchar(100), ErrorDescription varchar(max), Dated datetime)

insert into tbl_logs
select 'Package Started','',0,getdate()
insert into tbl_errors
select '2 logging', 'clean table', 'this is my error', getdate()

select * from tbl_logs
select * from tbl_errors